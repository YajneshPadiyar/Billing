<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'webuser');
define('DB_PASSWORD', 'qQUuYMNNHcezbvd9');
define('DB_HOST', '127.0.0.1:3306');
define('DB_NAME', 'billing');

?>
