myApp.factory("Constant",[function(){
	var constant = {
		"AppTitle":"Ganesh Silks",
		"AppTagLine":"Wedding Silks and Sarees",
		"service":"php/application/"
		};
	return constant;
}]);